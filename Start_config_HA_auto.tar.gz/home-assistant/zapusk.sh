#!/bin/bash

### добавить выбор WB/mini_pc
#read -p "Введите 1 если установка проходит на контроллере Wirenboard или 2 в любом другом случае:" platform
### Если mini pc добавить создание папок /mnt/data и /mnt/data/etc

mkdir /mnt/data/etc


read -p "Введите название устройства для бэкапа: " userr_ip

echo "Теперь меня зовут: $userr_ip"


#проверяем, установлен ли докер, если нет, ставим
if [ -x "$(command -v docker)" ]; then
   echo "Docker installed"
   cd /mnt/data/home-assistant
   docker compose up -d
else
   echo "Docker not installed. Install..."

   #Установка необходимых зависимостей
   apt update && apt install ca-certificates curl gnupg lsb-release -y

   #Добавление репозитория с пакетами docker
   echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] \
   https://download.docker.com/linux/debian $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null

   #Добавление GPG ключа для репозитория
   curl -fsSL https://download.docker.com/linux/debian/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

   #Docker пока не поддерживает nftables, который заменил iptables в новом bullseye — поэтому,
   #если у вас релиз wb-2304 и новее, надо выполнить по очереди:
   apt install -y iptables

   update-alternatives --set iptables /usr/sbin/iptables-legacy

   update-alternatives --set ip6tables /usr/sbin/ip6tables-legacy

   #Симлинк для папки конфигурации
   mkdir /mnt/data/etc/docker && ln -s /mnt/data/etc/docker /etc/docker

   #Создание папки для хранения образов
   mkdir /mnt/data/.docker

   #Указываем в файле настроек папку, созданную выше
   #Путь к файлу настроек
   config_file="/etc/docker/daemon.json"

   #Проверяем, существует ли файл, если нет - создаем его
   if [ ! -f "$config_file" ]; then
      sudo touch "$config_file"
   fi

   #Добавляем строки в файл
   echo '{
      "data-root": "/mnt/data/.docker"
      }' | sudo tee "$config_file" > /dev/null

   echo "Файл настроек $config_file успешно создан и заполнен."

   #После того, как мы указали, где будут хранится контейнеры, устанавливаем сам docker
   apt update && apt install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin -y

   #Чтобы не было ошибки permission denied unix:///var/run/docker.sock
   # необходимо добавить текущего пользователя в группу и назначить права на docker.sock
   usermod -aG docker ${USER}

   chmod 666 /var/run/docker.sock
   
   # Запускаем контейнеры
   cd /mnt/data/home-assistant
   docker compose up -d
   
fi

#Проверяем, установлен ли rsync и если нет, ставим
if [ -x "$(command -v rsync)" ]; then
   echo "Rsync installed."
else
   echo "Rsync not installed. Install..."
    
   #Обновляем индекс пакетов
   apt update && apt install rsync -y
fi

#В папке /mnt/data создаем папку backup
mkdir /mnt/data/backup

#Создаем скрипт backup.sh для бэкапа
echo '#!/bin/bash' > /mnt/data/backup.sh
echo 'tar --exclude='\''/mnt/data/backup'\'' -czvf /mnt/data/backup/'${userr_ip}'_$(date '\''+%d-%m-%Y'\'').tar.gz /mnt/data*' >> /mnt/data/backup.sh
echo 'find /mnt/data/backup -type f -mtime +30 -delete' >> /mnt/data/backup.sh
   
#Даем права на выполнение созданному скрипту
chmod +x /mnt/data/backup.sh
   
echo "Скрипт backup.sh успешно создан."

docker compose restart

echo "0 0 * * * root /mnt/data/backup.sh" >> /etc/cron.d/backupwb
chmod 600 /etc/cron.d/backupwb
echo "Задача CRON добавлена"
/etc/init.d/cron restart
echo "CRON перезапущен"
   
   

































    
